## ----------------------------------------------------------------------
## GPPYTHON 4.2.2.0
## ----------------------------------------------------------------------

if [ -h /usr/local/gppython ]; then
    GPPYTHONHOME=${GPPYTHONHOME=/usr/local/gppython}
else
    GPPYTHONHOME=${GPPYTHONHOME=/usr/local/gppython-4.2.2.0}
fi

PATH=$GPPYTHONHOME/bin:$GPPYTHONHOME/ext/python/bin:$PATH
LD_LIBRARY_PATH=$GPPYTHONHOME/lib:$GPPYTHONHOME/ext/python/lib:$LD_LIBRARY_PATH
PYTHONPATH=$GPPYTHONHOME/lib/python
PYTHONHOME=$GPPYTHONHOME/ext/python
GPHOME=${GPPYTHONHOME}

export GPHOME
export GPPYTHONHOME
export PATH
export LD_LIBRARY_PATH
export PYTHONPATH
export PYTHONHOME
